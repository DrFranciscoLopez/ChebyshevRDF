function testLatticeWithNoiseandVacancies()
    % Parameters for the lattice
    n =21; % Number of squares per side
    side_length = 1; % Lattice constant (d)
    angle = 120; % Rotation angle in degrees
    sigma_fraction = 0; % Fraction of the lattice constant for sigma
    vacancy_percent = 0; % Percentage of vacancies (0 to 99)

    % Convert angle from degrees to radians
    theta = deg2rad(angle);

    % Rotation matrix
    R = [cos(theta), -sin(theta); sin(theta), cos(theta)];

    % Generate the rotated lattice
    index = 1; % Index to track the current lattice point
    x_rotated = zeros((n+1)*(n+1), 1); % Preallocate array for rotated x-coordinates
    y_rotated = zeros((n+1)*(n+1), 1); % Preallocate array for rotated y-coordinates
    for i = 0:n
        for j = 0:n
            x = i * side_length; % x-coordinate of the original lattice point
            y = j * side_length; % y-coordinate of the original lattice point
            rotated_coords = R * [x; y]; % Apply rotation matrix
            x_rotated(index) = rotated_coords(1); % Store rotated x-coordinate
            y_rotated(index) = rotated_coords(2); % Store rotated y-coordinate
            index = index + 1; % Increment index
        end
    end
    rotated_grid = [x_rotated, y_rotated]; % Combine x and y coordinates into a single matrix

    % Apply noise to the rotated lattice
    noisy_grid = addNoiseToLattice(rotated_grid, side_length, sigma_fraction);

    % Introduce vacancies randomly
    num_points = size(noisy_grid, 1);
    num_vacancies = round(vacancy_percent / 100 * num_points); % Number of vacancies
    vacancy_indices = randperm(num_points, num_vacancies); % Random indices for vacancies
    noisy_grid_with_vacancies = noisy_grid;
    noisy_grid_with_vacancies(vacancy_indices, :) = []; % Remove points to create vacancies

    % Plot the original and noisy lattice with vacancies
    figure;
    hold on;
    scatter(rotated_grid(:,1), rotated_grid(:,2), 50, 'b', 'filled', 'DisplayName', 'Original lattice'); % Original lattice
    scatter(noisy_grid_with_vacancies(:,1), noisy_grid_with_vacancies(:,2), 50, 'r', 'filled', 'DisplayName', sprintf('Noisy lattice (%.0f%% Vacancies)', vacancy_percent)); % Noisy lattice
    axis equal; % Set equal scaling for axes
    legend; % Add a legend
    xlabel('X Coordinate'); % Label for the x-axis
    ylabel('Y Coordinate'); % Label for the y-axis
    title(sprintf('Rotated Square Lattice with Noise and Vacancies (Angle: %.2f°, Noise: %.2fσ)', angle, sigma_fraction)); % Title
    hold off;

    % Export the results to files
    filename_original = sprintf('Rotated_square_latt_%.2fdeg.txt', angle); % Filename for original lattice
    filename_noisy = sprintf('%.2fn_Noisy_rotated_square_latt_%.2fdeg_%.2fsigma_%.0fpercent_vacancies.txt',n, angle, sigma_fraction, vacancy_percent); % Filename for noisy lattice with vacancies
    writematrix(rotated_grid, filename_original, 'Delimiter', 'tab'); % Save original lattice to file
    writematrix(noisy_grid_with_vacancies, filename_noisy, 'Delimiter', 'tab'); % Save noisy lattice with vacancies to file
end

function noisy_grid = addNoiseToLattice(grid, side_length, sigma_fraction)
    % Add random noise to the lattice points
    sigma = sigma_fraction * side_length; % Noise standard deviation
    noise = sigma * randn(size(grid)); % Generate noise
    noisy_grid = grid + noise; % Add noise to grid
end

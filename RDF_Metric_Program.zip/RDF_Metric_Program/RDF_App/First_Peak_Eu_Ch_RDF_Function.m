function [X, Y] = First_Peak_Eu_Ch_RDF_Function(Data, Rlim, NumBins, Metric)
% Computes the 1D-RDF (Radial Distribution Function) for a set of 2D data points,
% using either the Euclidean or Chebyshev metric. The function identifies
% the first non-zero value of the RDF and stops further calculations.

% Find the bounding box of the dataset.
Xmax = max(Data(:,1));
Ymax = max(Data(:,2));
Xmin = min(Data(:,1));
Ymin = min(Data(:,2));

% Define the rectangular bounding region as a polygon.
rect = polyshape([Xmin, Xmin, Xmax, Xmax], [Ymax, Ymin, Ymin, Ymax]);

% Determine the number of data points.
n = size(Data, 1);

% Calculate the total number of possible particle pairs.
N = n * (n - 1) / 2;
D = zeros(N, 1); % Pre-allocate array for pairwise distances.

l1 = 1; % Start index for storing distances.
l2 = 0; % End index for storing distances.

% Define the edges of the bins for RDF calculation.
edges = linspace(0, Rlim, NumBins + 1);
L = edges(1:NumBins);       % Left edge of each bin.
R = edges(2:NumBins + 1);   % Right edge of each bin.

% Pre-allocate space to track areas for normalization.
edges_track = zeros(length(edges) - 1, 1);

% Loop through each particle to compute pairwise distances.
for i = 1:n-1
    % Select a particle (reference point).
    Pt = Data(i, :);
    % Define the remaining particles for distance calculation.
    Mat = Data(i+1:n, :);

    % Compute x and y differences between the reference and other points.
    X_temp = Mat(:, 1) - Pt(1);
    Y_temp = Mat(:, 2) - Pt(2);

    % Calculate distances based on the chosen metric.
    if Metric == 1
        % Euclidean distance.
        D_temp = sqrt(X_temp.^2 + Y_temp.^2);
    elseif Metric == 2
        % Chebyshev distance.
        D_temp = max(abs(X_temp), abs(Y_temp));
    else
        error('Invalid Metric: Choose 1 (Euclidean) or 2 (Chebyshev)');
    end

    j = n - i; % Number of distances to process for this particle.
    l2 = l2 + j; % Update end index for storing distances.
    
    % Store computed distances.
    D(l1:l2, 1) = D_temp;
    l1 = l1 + j; % Update start index for the next loop.
end

% Retain only distances within the specified radial limit.
Z = D <= Rlim;
D = D(Z);

% Bin the distances into the defined bins.
[V, ~] = histcounts(D, edges);

% Calculate the average density of particles in the bounding region.
p = n / ((Xmax - Xmin) * (Ymax - Ymin));

% Compute the expected number of particles per bin for an ideal gas.
Nid = p * (pi * (R.^2 - L.^2)); % Approximation of bin areas.

% Calculate the center of each bin for the RDF.
X = (L + R) ./ 2;

% Normalize the RDF values and check for the first non-zero value.
Y = zeros(size(V)); % Pre-allocate Y.
for idx = 1:length(V)
    if Nid(idx) > 0 % Avoid division by zero.
        Y(idx) = (V(idx) / Nid(idx)) * 2; % Normalize g(R).
    end
    if Y(idx) > 0
        % Stop when the first non-zero g(R) is found.
        X = X(1:idx); % Trim X to the corresponding range.
        Y = Y(1:idx); % Trim Y to the corresponding range.
        return; % Exit the function.
    end
end
end
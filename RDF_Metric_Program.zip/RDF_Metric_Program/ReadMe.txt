﻿# RDF with Chebyshev Metric for Square Lattice Orientation

This MATLAB-based application calculates the Radial Distribution Function (RDF) using the Chebyshev metric to analyze the orientation of rotated square lattices. 
It extends the functionality of CORDERLY and allows users to compute RDF, visualize results and determine crystal orientation.

## Key Features:

- **RDF Calculation**: Compute RDF using Chebyshev (anisotropic) and Euclidean (isotropic) metrics.
- **Orientation Analysis**: Analyze the orientation of rotated square lattices.
- **Visualization**: Visualize RDF plots and export results to CSV.
- **Simulation**: Square lattice data generator for creating simulation data.

## Dependencies:

- MATLAB R2021a or higher
- MATLAB Compiler Runtime (required for running compiled executables)

## Usage Instructions:

1. **Download and Extract**: Clone or download this repository and extract the files.
2. **Run the Application**:
   - In MATLAB, open the app file (RDF_Metric.mlapp ).
   - Alternatively, you can use the executable if you're not running MATLAB.
3.     Input Parameters:
        Select the file containing the 2D coordinates of points (see HELP for more details).
        Select the RDF method (see HELP for more details).
        Select the metric: Choose between Euclidean or Chebyshev.
        Select the number of bins (see HELP for more details).

4.     Export Results:
        View and visualize RDF results.
        Export results as a CSV file for further analysis.
        If your data consists of a noisy or perfect rotated square lattice, with or without vacancies, click the "Calculate Square Lattice Orientation" button to determine the orientation using the First Peak Chebyshev Method
 (described in the forthcoming article: “Use of the radial distribution function with the Chebyshev distance to characterize orientation of two-dimensional square crystals” (F. López-González et al., under review in *Physical Review E*)..).

See HELP for more details. A rotated square lattice generator is included in the app; see HELP for further instructions.

## Forked from CORDERLY

This repository is a fork of the CORDERLY project, created by N. M. Fhionnlaoich, R. Qi, S. Guldin. The original repository is available here: https://github.com/AdReNa-lab/CORDERLY

### Changes Made:

1. **Chebyshev Metric Integration**: Modified the RDF calculation to include Chebyshev (anisotropic) distance alongside Euclidean (isotropic) distance for improved orientation analysis of square lattices.
2. **Crystal Orientation Analysis**: Added functionality for determining the orientation of rotated square lattices.
3. **CSV Export**: Added functionality to export RDF results to CSV for easier post-processing.

## Original Functionality (CORDERLY):

CORDERLY is primarily focused on using the spatial distribution function (SDF) to analyze colloidal ordering. You can find the original work and its description in the following publication: https://pubs.acs.org/doi/10.1021/acs.langmuir.9b02877.

## Citing the Work:

If you use this program in your research, please cite the following references:

1. **CORDERLY**: N. M. Fhionnlaoich, R. Qi, S. Guldin, "Application of the spatial distribution function to colloidal ordering," *Langmuir*, 35 (50), 2019. DOI: https://pubs.acs.org/doi/10.1021/acs.langmuir.9b02877.
2. **Forthcoming Article**: “Use of the radial distribution function with the Chebyshev distance to characterize orientation of two-dimensional square crystals” (F. López-González et al., under review in *Physical Review E*).

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact Information:

For questions or support, please contact francisco_lopez@uaeh.edu.mx

